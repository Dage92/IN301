int CanSliderMove(SLIDER S);

SLIDER MoveSlider(SLIDER S);

SLIDER MoveUp(SLIDER S);

SLIDER MoveRight(SLIDER S);

SLIDER MoveLeft (SLIDER S);

SLIDER MoveDown (SLIDER S);
