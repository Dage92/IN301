
void initialiser_affichage(SLIDER S);

void afficher_grille(SLIDER S);

void afficher_border(SLIDER S);

void afficher_murs(SLIDER S);

void afficher_le_slider(SLIDER S);

void afficher_sortie(SLIDER S);

void afficher_slider (SLIDER S);

void finir_affichage(SLIDER S);
