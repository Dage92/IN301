
SLIDER lire_fichier(char * nom);

void ecrire_fichier(SLIDER S, char*nom);
